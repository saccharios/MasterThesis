/*
This demo program let the e-puck recording for about two seconds whatever you like and then
reproduces it infinitely.
The program starts with a led animation (flow) and then turns all leds on for about two seconds,
this is the moment for recording; note that only the right micro (mic0) is used.
With the selector you can choose the volume/amplification (from 1 to 16) of the reproduction.

Author: Stefano Morgani
*/

#include "p30f6014A.h"

#include "stdio.h"
#include "string.h"
#include <math.h>
#include "a_d/advance_ad_scan/e_ad_conv.h"
#include "codec/e_sound.h"
#include "utility.h"
#include "motor_led/e_init_port.h"
#include "uart/e_uart_char.h"
#include "motor_led/e_epuck_ports.h"
#include "motor_led/advance_one_timer/e_led.h"

extern char __attribute((far)) e_mic_scan[MIC_SAMP_NB];		// array to store the samples

extern unsigned int e_dci_unavailable;

#define PI 3.14159265358979

#define uart2_send_static_text(msg) { e_send_uart2_char(msg,sizeof(msg)-1); while(e_uart2_sending()); }
#define uart1_send_static_text(msg) { e_send_uart1_char(msg,sizeof(msg)-1); while(e_uart1_sending()); }

#define SELECTOR0 _RG6
#define SELECTOR1 _RG7
#define SELECTOR2 _RG8
#define SELECTOR3 _RG9

int main() {

	unsigned int i=0, j=0,k=0, selector=1;
	unsigned char buf[2]; //c1, c2;
	char toSend[5];
	double angle=0.0;

	//system initialization 
	e_init_port();    	// configure port pins
	e_init_uart1();   	// initialize UART to 115200 Kbaud
	//e_init_uart2();   	// initialize UART to 115200 Kbaud

	//Reset if Power on (some problem for few robots)
	if (RCONbits.POR) {
		RCONbits.POR=0;
		__asm__ volatile ("reset");
	}

	selector=getselector()+1;

	// advise the user to prepare to recording
	for(j=0; j<5; j++) {
		flow_led();
		for(i=0; i<65000; i++)
			for(k=0; k<10; k++);
	}

	e_set_led(8,0);
	for(i=0; i<65000; i++)
		for(k=0; k<10; k++);

	e_set_led(8,1);
	e_init_ad_scan(MICRO_ONLY);	// configure ADC and start acquisition
	do
	{
		NOP();
	}
	while(!e_ad_is_array_filled());
	IEC0bits.ADIE = 0;		// disable interrupt
	ADCON1bits.ADON = 0;		// disable AD conversion (avoid interferes with the calculations)
	e_set_led(8,0);	

	// send the values through the serial line
	/*
	for(i=0; i<3600; i++) {
		buf[0]=e_mic_scan[i]>>8;
		buf[1]=e_mic_scan[i]&0xFF;
		e_send_uart2_char(buf,2);
		while(e_uart2_sending());
		for(j=0; j<20000; j++);
	}*/
	/*
	e_send_uart2_char((unsigned char*)e_mic_scan, 7200);
	while(e_uart2_sending());
	*/
	/*
	for(i=0; i<3600; i++) {
		e_send_uart2_char((unsigned char*)&e_mic_scan[i*2],2);
		while(e_uart2_sending());
		for(j=0; j<20000; j++);
	}
	*/

	// amplify the samples based on selector
	for(i=0; i<MIC_SAMP_NB; i++) {
		e_mic_scan[i]*=selector;
	}
	
	
	// fill in the buffer with a sine wave
	/*
	i=0;
	for(j=0; j<MIC_SAMP_NB; j++) {
		//for(angle=0; angle<2.0*PI; angle+=2.0*PI/36.0) {
			//e_mic_scan[j]=(int)(sin(3*j)*5000.0);
			e_mic_scan[j]=(char)((sin(10*j))*128.0);
			//i++;
		//}
	}
	*/

	// send some values through the bluetooth line
	/*
	for(j=0; j<100; j++) {
		sprintf(toSend,"%d\r\n", e_mic_scan[j]);
		e_send_uart1_char(toSend,strlen(toSend));
		memset(toSend,0x0, 5);
	}
	*/

	e_init_sound();
	while(1) {
		e_play_sound(e_mic_scan, MIC_SAMP_NB);
		while(e_dci_unavailable);	// wait until the DCI module stop playing
	}

	return 0;
}

